
package Controlador;

import Modelo.NodoUsuario;
import javax.swing.*;

public class Login extends JFrame {
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JButton btnIngresar;

    private ListaUsuarios listaUsuarios;   
    private NodoUsuario nodoAutenticado;   

    public Login() {
        setTitle("Login");
        setSize(300, 180);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // Inicializa la lista de usuarios
        listaUsuarios = new ListaUsuarios();

        JLabel lblUsuario = new JLabel("Usuario:");
        JLabel lblContrasena = new JLabel("Contraseña:");
        txtUsuario = new JTextField();
        txtContrasena = new JPasswordField();
        btnIngresar = new JButton("Ingresar");

        lblUsuario.setBounds(30, 20, 80, 25);
        txtUsuario.setBounds(120, 20, 130, 25);
        lblContrasena.setBounds(30, 55, 80, 25);
        txtContrasena.setBounds(120, 55, 130, 25);
        btnIngresar.setBounds(90, 95, 100, 30);

        add(lblUsuario);
        add(txtUsuario);
        add(lblContrasena);
        add(txtContrasena);
        add(btnIngresar);

        btnIngresar.addActionListener(e -> {
            String usuarioIngresado = txtUsuario.getText();
            String pass = new String(txtContrasena.getPassword());

            nodoAutenticado = listaUsuarios.validar(usuarioIngresado, pass);

            if (nodoAutenticado != null) {
                JOptionPane.showMessageDialog(this, "Bienvenido " + nodoAutenticado.getNombreUsuario());
                // Abrir siguiente ventana aquí...
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrecta");
            }
        });
    }

    public static void main(String[] args) {
        new Login().setVisible(true);
    }
}