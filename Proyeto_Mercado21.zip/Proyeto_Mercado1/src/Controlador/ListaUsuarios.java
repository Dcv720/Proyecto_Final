/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.NodoUsuario;

public class ListaUsuarios {
    private NodoUsuario cabeza;
    private NodoUsuario cola;

    public ListaUsuarios() {
        cabeza = null;
        cola = null;
        // Añade algunos usuarios por defecto
        agregarUsuario("user", "12345");
        agregarUsuario("Daniela", "0928");
    }

    public void agregarUsuario(String usuario, String contrasena) {
        NodoUsuario nuevo = new NodoUsuario(usuario, contrasena);
        if (cabeza == null) {
            cabeza = nuevo;
            cola = nuevo;
        } else {
            cola.siguiente = nuevo;
            nuevo.anterior = cola;
            cola = nuevo;
        }
    }

    public NodoUsuario validar(String usuario, String contrasena) {
        NodoUsuario actual = cabeza;
        while (actual != null) {
            if (actual.getNombreUsuario().equals(usuario) && actual.getContrasena().equals(contrasena)) {
                return actual;
            }
            actual = actual.siguiente;
        }
        return null;
    }
}