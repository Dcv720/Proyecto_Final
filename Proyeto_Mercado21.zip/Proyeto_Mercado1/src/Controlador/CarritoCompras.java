/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.ItemCarrito;
import Modelo.NodoCarrito;
import Modelo.Producto;

public class CarritoCompras {
    private NodoCarrito cabeza;

    public CarritoCompras() {
        this.cabeza = null;
    }

    // Agrega un nuevo item al final del carrito
    public void agregarItem(Producto producto, int cantidad) {
        ItemCarrito nuevoItem = new ItemCarrito(producto, cantidad);
        NodoCarrito nuevoNodo = new NodoCarrito(nuevoItem);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            NodoCarrito actual = cabeza;
            while (actual.getSiguiente() != null) {
                actual = (NodoCarrito) actual.getSiguiente();
            }
            actual.setSiguiente(nuevoNodo);
        }
    }

    // Elimina un item del carrito según el nombre del producto
    public void eliminarItem(String nombreProducto) {
        if (cabeza == null) return;

        if (cabeza.getItem().getProducto().getNombre().equalsIgnoreCase(nombreProducto)) {
            cabeza = (NodoCarrito) cabeza.getSiguiente();
            return;
        }

        NodoCarrito actual = cabeza;
        while (actual.getSiguiente() != null) {
            if (actual.getSiguiente().getItem().getProducto().getNombre().equalsIgnoreCase(nombreProducto)) {
                actual.setSiguiente(actual.getSiguiente().getSiguiente());
                return;
            }
            actual = (NodoCarrito) actual.getSiguiente();
        }
    }

    // Actualiza la cantidad de un producto en el carrito
    public void actualizarCantidad(String nombreProducto, int nuevaCantidad) {
        NodoCarrito actual = cabeza;
        while (actual != null) {
            if (actual.getItem().getProducto().getNombre().equalsIgnoreCase(nombreProducto)) {
                actual.getItem().setCantidad(nuevaCantidad);
                return;
            }
            actual = (NodoCarrito) actual.getSiguiente();
        }
    }

    // Calcula el total del carrito sumando los subtotales
    public double calcularTotal() {
        double total = 0;
        NodoCarrito actual = cabeza;
        while (actual != null) {
            total += actual.getItem().calcularSubtotal();
            actual = (NodoCarrito) actual.getSiguiente();
        }
        return total;
    }

    // Devuelve una representación en texto del carrito
    public String mostrarCarrito() {
        StringBuilder sb = new StringBuilder("Carrito de Compras:\n");
        NodoCarrito actual = cabeza;
        if (actual == null) {
            return "El carrito está vacío.";
        }
        while (actual != null) {
            sb.append(actual.getItem().toString()).append("\n");
            actual = (NodoCarrito) actual.getSiguiente();
        }
        sb.append("------------------------\n");
        sb.append("Total: $").append(String.format("%.2f", calcularTotal()));
        return sb.toString();
    }

    // Devuelve la cabeza de la lista
    public NodoCarrito getCabeza() {
        return cabeza;
    }
}