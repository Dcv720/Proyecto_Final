
package Modelo;

/**
 *
 * @author Compaq 18
 */

public class NodoUsuario {
    private String nombreUsuario;
    private String contrasena;

    public NodoUsuario anterior;
    public NodoUsuario siguiente;

    public NodoUsuario(String nombreUsuario, String contrasena) {
        this.nombreUsuario = nombreUsuario;
        this.contrasena = contrasena;
        this.anterior = null;
        this.siguiente = null;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }
}

