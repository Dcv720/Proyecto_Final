    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

public class NodoCarrito {
    private ItemCarrito item;
    private NodoCarrito siguiente;

    public NodoCarrito(ItemCarrito item) {
        this.item = item;
        this.siguiente = null;
    }

    public ItemCarrito getItem() {
        return item;
    }

    public NodoCarrito getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoCarrito siguiente) {
        this.siguiente = siguiente;
    }
}
