/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Compaq 18
 */
public class NodoCarrito {
    public ItemCarrito item;
    public NodoCarrito siguiente;

    public NodoCarrito(ItemCarrito item) {
        this.item = item;
        this.siguiente = null;
    }   
}
