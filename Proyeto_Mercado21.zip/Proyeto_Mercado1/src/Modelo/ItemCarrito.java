package Modelo;

public class ItemCarrito {
    private Producto producto;
    private int cantidad;

    public ItemCarrito(Producto producto, int cantidad) {
        this.producto = producto;
        this.cantidad = cantidad;
    }

    public Producto getProducto() {
        return producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double calcularSubtotal() {
        return producto.getPrecio() * cantidad;
    }

    @Override
    public String toString() {
        return "Producto: " + producto.getNombre() +
               ", Cantidad: " + cantidad +
               ", Precio Unitario: $" + String.format("%.2f", producto.getPrecio()) +
               ", Subtotal: $" + String.format("%.2f", calcularSubtotal());
    }
}
